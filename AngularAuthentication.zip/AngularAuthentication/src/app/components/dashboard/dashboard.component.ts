import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { AuthService } from 'src/app/service/auth.service';
import { HttpErrorResponse } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { Employee } from 'src/app/service/employee';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

modalVisible: boolean = false;
  message: String;
  employees: any[];
  employeeData: any = {
    name: '',
    jobTitle: '',
    phone: '',
    email: '',
    imageUrl: ''
  };
  
  oldEmp: any;

  constructor(
    private service: AuthService,
    private router: Router
  ) { }

  ngOnInit() {
    this.hello();
    this.getEmployees();
  }


  hello() {
    this.service.hello().subscribe((response) => {
      console.log(response);
      this.message = response.message;
    })
  } 
  logout(){
  this.service.removeToken();
    this.router.navigateByUrl('/login');


  }

 
  openModal() {
    this.modalVisible = true;
  }


  getEmployees(): void {
    this.service.getAllEmployees().subscribe(data => {
      this.employees = data;
    });
  }

  addEmployee(): void {
    this.service.addEmployee(this.employeeData)
      .subscribe(response => {
        console.log('Adding employee:', this.employeeData);
        // Optionally, reset the form or perform any other actions upon successful addition
        this.getEmployees();
      }, error => {
        console.error('Error adding employee:', error);
      });
  }
  clearForm() {
    this.employeeData = {}; // Resetting the employee data object
  }

  // updateEmployee(employeeData: any): void {
  //   this.service.updateEmployee(employeeData).subscribe(() => {
  //     this.getEmployees();
  //   });
  // }

  deleteEmployee(employeeId: number): void {
    this.service.deleteEmployee(employeeId).subscribe(() => {
      this.getEmployees();
    });
  }
  onEmployeeAdded(data: any) {
    // Here you can handle the added employee data
    console.log('Employee added:', data);
    // You might want to close the modal after adding the employee
    this.modalVisible = false;
  }

  updateEmployee(employee:any){
    this.oldEmp=JSON.stringify(employee)
    this.employees.forEach(element =>{
      element.isEdit=false;
    })
    employee.isEdit = true;

  }
  
  onUpdate(employee:any){
   
    this.service.updateEmployee(employee).subscribe(() => {
         this.getEmployees();
    });

  }

  onCancel(employee:any){
    employee.isEdit=false;
    const oldEmp = JSON.parse(this.oldEmp)
    employee.name = oldEmp.name;
    employee.jobTitle = oldEmp.jobTitle;
    employee.phone = oldEmp.phone;
    employee.email = oldEmp.email;
    employee.imageUrl = oldEmp.imageUrl;

  }


  
  
  // public getEmployees(): void {
  //   this.service.getEmployees().subscribe(
  //     (response: Employee[]) => {
  //       this.employees = response;
  //       console.log(this.employees);
  //     },
  //     (error: HttpErrorResponse) => {
  //       alert(error.message);
  //     }
  //   );
  // }

  // public onAddEmloyee(addForm: NgForm): void {
  //   document.getElementById('add-employee-form').click();
  //   this.service.addEmployee(addForm.value).subscribe(
  //     (response: Employee) => {
  //       console.log(response);
  //       this.getEmployees();
  //       addForm.reset();
  //     },
  //     (error: HttpErrorResponse) => {
  //       alert(error.message);
  //       addForm.reset();
  //     }
  //   );
  // }

  // public onUpdateEmloyee(employee: Employee): void {
  //   this.service.updateEmployee(employee).subscribe(
  //     (response: Employee) => {
  //       console.log(response);
  //       this.getEmployees();
  //     },
  //     (error: HttpErrorResponse) => {
  //       alert(error.message);
  //     }
  //   );
  // }

  // public onDeleteEmloyee(employeeId: number): void {
  //   this.service.deleteEmployee(employeeId).subscribe(
  //     (response: void) => {
  //       console.log(response);
  //       this.getEmployees();
  //     },
  //     (error: HttpErrorResponse) => {
  //       alert(error.message);
  //     }
  //   );
  // }

  // // public searchEmployees(key: string): void {
  // //   console.log(key);
  // //   const results: Employee[] = [];
  // //   for (const employee of this.employees) {
  // //     if (employee.name.toLowerCase().indexOf(key.toLowerCase()) !== -1
  // //     || employee.email.toLowerCase().indexOf(key.toLowerCase()) !== -1
  // //     || employee.phone.toLowerCase().indexOf(key.toLowerCase()) !== -1
  // //     || employee.jobTitle.toLowerCase().indexOf(key.toLowerCase()) !== -1) {
  // //       results.push(employee);
  // //     }
  // //   }
  // //   this.employees = results;
  // //   if (results.length === 0 || !key) {
  // //     this.getEmployees();
  // //   }
  // // }

  // // public onOpenModal(employee: Employee, mode: string): void {
  // //   const container = document.getElementById('main-container');
  // //   const button = document.createElement('button');
  // //   button.type = 'button';
  // //   button.style.display = 'none';
  // //   button.setAttribute('data-toggle', 'modal');
  // //   if (mode === 'add') {
  // //     button.setAttribute('data-target', '#addEmployeeModal');
  // //   }
  // //   if (mode === 'edit') {
  // //     this.editEmployee = employee;
  // //     button.setAttribute('data-target', '#updateEmployeeModal');
  // //   }
  // //   if (mode === 'delete') {
  // //     this.deleteEmployee = employee;
  // //     button.setAttribute('data-target', '#deleteEmployeeModal');
  // //   }
  // //   container.appendChild(button);
  // //   button.click();
  // // }



}

