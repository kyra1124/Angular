import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Employee } from './employee';
import { BaseRouteReuseStrategy } from '@angular/router';

const BASE_URL = ['http://localhost:8080/']

@Injectable({
  providedIn: 'root'
})
export class AuthService {

 
  private apiUrl = 'http://localhost:8080/api/';
  

  constructor(
    private http: HttpClient
  ) { }



  signup(signupRequest: any): Observable<any> {
    return this.http.post(BASE_URL + "sign-up", signupRequest)
  }

  login(loginRequest: any): Observable<any> {
    return this.http.post(BASE_URL + "authenticate", loginRequest)
  }
 
  removeToken() {
    localStorage.removeItem('JWT')
  }

  hello(): Observable<any> {
    return this.http.get(BASE_URL + 'api/hello', {
      headers: this.createAuthorizationHeader()
    });
  }

  private createAuthorizationHeader() {
    const jwtToken = localStorage.getItem('JWT');
    if (jwtToken) {
      return new HttpHeaders().set(
        'Authorization', 'Bearer ' + jwtToken
      )
    } else {
      console.log("JWT token not found in the Local Storage");
    }
    return null;
  }

    



  getAllEmployees(): Observable<any[]> {
    return this.http.get<any[]>(this.apiUrl + 'all',{
      headers:this.createAuthorizationHeader()
    });
  }

  addEmployee(employeeData: object): Observable<any> {
    return this.http.post<any>(this.apiUrl + 'add', employeeData,{
      headers:this.createAuthorizationHeader()
    });
  }

  updateEmployee(employeeData: any): Observable<any> {
    return this.http.put<any>(this.apiUrl + 'update', employeeData,{
      headers:this.createAuthorizationHeader()
    });
  }

  deleteEmployee(employeeId: number): Observable<any> {
    return this.http.delete<any>(`${this.apiUrl}delete/${employeeId}`,{
      headers:this.createAuthorizationHeader()
    });
  }
}













//    public addEmployee(employee: Employee): Observable<Employee> {
//     return this.http.post<Employee>(`${this.apiServerUrl}add`, employee,{
//       headers:this.createAuthorizationHeader()
//     });  }


//     public updateEmployee(employee: Employee): Observable<Employee> {
//       return this.http.put<Employee>(`${this.apiServerUrl}update`, employee,{
//         headers:this.createAuthorizationHeader()
//       });  }

//        public deleteEmployee(employeeId: number): Observable<void> {
//             return this.http.delete<void>(`${this.apiServerUrl}delete/${employeeId}`,{
//               headers:this.createAuthorizationHeader()
//             });
// }

    



//   public getEmployees(): Observable<Employee[]> {
//     return this.http.get<Employee[]>(`${this.apiServerUrl}/api/all`);
//   }

//   public addEmployee(employee: Employee): Observable<Employee> {
//     return this.http.post<Employee>(`${this.apiServerUrl}/api/add`, employee);
//   }

//   public updateEmployee(employee: Employee): Observable<Employee> {
//     return this.http.put<Employee>(`${this.apiServerUrl}/api/update`, employee);
//   }

//   public deleteEmployee(employeeId: number): Observable<void> {
//     return this.http.delete<void>(`${this.apiServerUrl}/api/delete/${employeeId}`);
//   }

 
